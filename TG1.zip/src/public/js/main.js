// Глобальные переменные
let isAuthenticated = false;

// Функции для работы с API
async function apiRequest(endpoint, options = {}) {
    try {
        console.log(`Making ${options.method || 'GET'} request to ${endpoint}`, options);
        const response = await fetch(`/api/${endpoint}`, {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                ...options.headers
            },
            credentials: 'same-origin'
        });

        const data = await response.json();
        console.log(`Response from ${endpoint}:`, data);

        if (!response.ok) {
            throw new Error(data.error || `HTTP error! status: ${response.status}`);
        }

        return data;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Аутентификация
async function handleLogin(event) {
    event.preventDefault();
    console.log('Login attempt started');
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await apiRequest('login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });

        console.log('Login response:', response);

        if (response.success) {
            isAuthenticated = true;
            showDashboard();
            await loadDashboardData();
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('Ошибка входа: ' + error.message);
    }
}

async function logout() {
    try {
        await apiRequest('logout', { method: 'POST' });
        isAuthenticated = false;
        showLoginForm();
    } catch (error) {
        console.error('Logout error:', error);
        alert('Ошибка при выходе: ' + error.message);
    }
}

// Управление отображением
function showLoginForm() {
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('dashboard').style.display = 'none';
    // Очищаем поля формы
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
}

function showDashboard() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('dashboard').style.display = 'block';
}

// Загрузка данных дашборда
async function loadDashboardData() {
    try {
        console.log('Loading dashboard data...');
        const [stats, users] = await Promise.all([
            apiRequest('stats'),
            apiRequest('users')
        ]);

        console.log('Dashboard data loaded:', { stats, users });
        updateStats(stats);
        updateUsersTable(users);
    } catch (error) {
        console.error('Failed to load dashboard data:', error);
        if (error.message.includes('Unauthorized')) {
            isAuthenticated = false;
            showLoginForm();
        } else {
            alert('Ошибка загрузки данных: ' + error.message);
        }
    }
}

// Обновление статистики
function updateStats(stats) {
    document.getElementById('totalUsers').textContent = stats.totalUsers || 0;
    document.getElementById('activeUsers').textContent = stats.activeUsers || 0;
    document.getElementById('blockedUsers').textContent = stats.blockedUsers || 0;
}

// Обновление таблицы пользователей
function updateUsersTable(data) {
    const tbody = document.getElementById('usersTableBody');
    tbody.innerHTML = '';

    if (!data.users) return;

    Object.entries(data.users).forEach(([userId, user]) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${userId}</td>
            <td>
                <span class="status-badge ${user.status}">${user.status}</span>
            </td>
            <td>${user.contextLimit}</td>
            <td>${new Date(user.lastActive).toLocaleString()}</td>
            <td>
                ${createActionButtons(userId, user)}
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Создание кнопок действий
function createActionButtons(userId, user) {
    const blockBtn = user.status === 'active' 
        ? `<button class="action-btn block-btn" onclick="blockUser('${userId}')">Блок</button>`
        : `<button class="action-btn unblock-btn" onclick="unblockUser('${userId}')">Разблок</button>`;

    return `
        ${blockBtn}
        <button class="action-btn edit-btn" onclick="showEditContextLimit('${userId}', ${user.contextLimit})">
            Изменить лимит
        </button>
    `;
}

// Действия с пользователями
async function blockUser(userId) {
    try {
        await apiRequest(`users/${userId}`, {
            method: 'PUT',
            body: JSON.stringify({ status: 'blocked' })
        });
        await loadDashboardData();
    } catch (error) {
        console.error('Failed to block user:', error);
        alert('Ошибка при блокировке пользователя: ' + error.message);
    }
}

async function unblockUser(userId) {
    try {
        await apiRequest(`users/${userId}`, {
            method: 'PUT',
            body: JSON.stringify({ status: 'active' })
        });
        await loadDashboardData();
    } catch (error) {
        console.error('Failed to unblock user:', error);
        alert('Ошибка при разблокировке пользователя: ' + error.message);
    }
}

// Изменение лимита контекста
function showEditContextLimit(userId, currentLimit) {
    const newLimit = prompt('Введите новый лимит контекста:', currentLimit);
    if (newLimit !== null) {
        const limit = parseInt(newLimit);
        if (!isNaN(limit) && limit > 0) {
            updateContextLimit(userId, limit);
        } else {
            alert('Пожалуйста, введите корректное число');
        }
    }
}

async function updateContextLimit(userId, newLimit) {
    try {
        await apiRequest(`users/${userId}`, {
            method: 'PUT',
            body: JSON.stringify({ contextLimit: newLimit })
        });
        await loadDashboardData();
    } catch (error) {
        console.error('Failed to update context limit:', error);
        alert('Ошибка при обновлении лимита контекста: ' + error.message);
    }
}

// Автоматическое обновление данных
let updateInterval;

function startAutoUpdate() {
    if (updateInterval) clearInterval(updateInterval);
    updateInterval = setInterval(() => {
        if (isAuthenticated) {
            loadDashboardData();
        }
    }, 30000); // Обновление каждые 30 секунд
}

function stopAutoUpdate() {
    if (updateInterval) {
        clearInterval(updateInterval);
        updateInterval = null;
    }
}

// Инициализация
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing...');
    
    // Находим форму входа
    const loginForm = document.getElementById('authForm');
    if (loginForm) {
        console.log('Login form found, attaching submit handler');
        loginForm.addEventListener('submit', handleLogin);
    } else {
        console.error('Login form not found!');
    }

    showLoginForm();
    startAutoUpdate();
});

// Обработка ошибок и автоматический выход при потере сессии
window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    if (event.reason.message.includes('Unauthorized')) {
        isAuthenticated = false;
        showLoginForm();
        stopAutoUpdate();
    }
});
