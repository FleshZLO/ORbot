const axios = require('axios');
const config = require('../config/config');

class OpenRouterAPI {
    constructor() {
        this.apiKey = config.openrouter.apiKey;
        this.baseURL = 'https://openrouter.ai/api/v1';
        this.model = config.openrouter.model;
    }

    async generateResponse(messages) {
        try {
            console.log('Sending request to OpenRouter:', {
                model: this.model,
                messagesCount: messages.length
            });

            const response = await axios.post(
                `${this.baseURL}/chat/completions`,
                {
                    model: this.model,
                    messages: messages.map(msg => ({
                        role: msg.role,
                        content: msg.content
                    })),
                    temperature: 0.7,
                    max_tokens: 1000,
                    stream: false
                },
                {
                    headers: {
                        'Authorization': `Bearer ${this.apiKey}`,
                        'HTTP-Referer': 'http://localhost:3000',
                        'Content-Type': 'application/json'
                    }
                }
            );

            console.log('OpenRouter response received:', {
                status: response.status,
                model: response.data.model,
                usage: response.data.usage
            });

            return response.data.choices[0].message.content;
        } catch (error) {
            console.error('OpenRouter API Error:', error.response?.data || error.message);
            if (error.response?.data) {
                throw new Error(`OpenRouter API Error: ${error.response.data.error || 'Unknown error'}`);
            }
            throw new Error('Ошибка при генерации ответа: ' + error.message);
        }
    }

    async validateApiKey() {
        try {
            const response = await axios.get(
                `${this.baseURL}/auth/key`,
                {
                    headers: {
                        'Authorization': `Bearer ${this.apiKey}`,
                        'Content-Type': 'application/json'
                    }
                }
            );
            return response.status === 200;
        } catch (error) {
            console.error('API Key validation error:', error.message);
            return false;
        }
    }
}

module.exports = new OpenRouterAPI();
