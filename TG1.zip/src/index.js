require('./bot');
require('./server');

process.on('uncaughtException', (error) => {
    console.error('Необработанное исключение:', error);
});

process.on('unhandledRejection', (error) => {
    console.error('Необработанное отклонение промиса:', error);
});

console.log('Бот и веб-сервер запущены...');
