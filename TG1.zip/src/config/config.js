require('dotenv').config();

module.exports = {
    telegram: {
        token: '7972935149:AAGXpGy5j8nOdqvPrYNiWE-ig17vHldL0D8'
    },
    openrouter: {
        apiKey: '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',
        model: 'gpt-3.5-turbo'
    },
    adminId: '351550362', // Установлен полученный Telegram ID
    defaults: {
        contextLimit: 30,          // Лимит контекста для обычных пользователей
        adminContextLimit: 1000,   // Лимит контекста для администратора
        userTimeout: 3600,         // Время в секундах до очистки контекста (1 час)
        backupInterval: 86400      // Интервал резервного копирования (24 часа)
    },
    admin: {
        username: 'admin',
        password: 'admin'
    }
};
