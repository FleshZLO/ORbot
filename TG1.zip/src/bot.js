const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs').promises;
const path = require('path');
const config = require('./config/config');
const openRouter = require('./utils/openrouter');

// Инициализация бота
const bot = new TelegramBot(config.telegram.token, { polling: true });

// Хранилище контекста в памяти
const userContexts = new Map();

// Функция для загрузки данных пользователя
async function loadUserData() {
    try {
        const data = await fs.readFile(path.join(__dirname, 'data/users.json'), 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error loading user data:', error);
        return { users: {} };
    }
}

// Функция для сохранения данных пользователя
async function saveUserData(data) {
    await fs.writeFile(
        path.join(__dirname, 'data/users.json'),
        JSON.stringify(data, null, 2)
    );
}

// Функция для сохранения контекста
async function saveContext(userId, context) {
    try {
        await fs.writeFile(
            path.join(__dirname, 'data/contexts', `${userId}.json`),
            JSON.stringify(context, null, 2)
        );
    } catch (error) {
        console.error('Error saving context:', error);
    }
}

// Функция для загрузки контекста
async function loadContext(userId) {
    try {
        const data = await fs.readFile(
            path.join(__dirname, 'data/contexts', `${userId}.json`),
            'utf8'
        );
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}

// Функция проверки администратора
function isAdmin(userId) {
    console.log('Проверка админа для ID:', userId);
    console.log('Текущий adminId в конфиге:', config.adminId);
    return userId.toString() === config.adminId;
}

// Обработка команды /start
bot.onText(/\/start/, async (msg) => {
    const userId = msg.from.id.toString();
    console.log('Получена команда /start от пользователя с ID:', userId);
    
    const userData = await loadUserData();
    
    if (!userData.users[userId]) {
        userData.users[userId] = {
            role: isAdmin(userId) ? 'admin' : 'user',
            status: 'active',
            contextLimit: isAdmin(userId) ? config.defaults.adminContextLimit : config.defaults.contextLimit,
            created: new Date().toISOString(),
            lastActive: new Date().toISOString()
        };
        await saveUserData(userData);
        console.log('Создан новый пользователь:', userData.users[userId]);
    }

    const message = isAdmin(userId) 
        ? 'Добро пожаловать, администратор! У вас расширенный контекст и доступ к командам управления.'
        : 'Добро пожаловать! Я бот с контекстной памятью. Можем начать общение.';
    
    bot.sendMessage(userId, message);
});

// Обработка команды /clear
bot.onText(/\/clear/, async (msg) => {
    const userId = msg.from.id.toString();
    userContexts.delete(userId);
    await fs.unlink(path.join(__dirname, 'data/contexts', `${userId}.json`)).catch(() => {});
    bot.sendMessage(userId, 'Контекст очищен.');
});

// Обработка команды /context
bot.onText(/\/context/, async (msg) => {
    const userId = msg.from.id.toString();
    const context = userContexts.get(userId) || await loadContext(userId) || [];
    const contextSize = context.length;
    bot.sendMessage(userId, `Текущий размер контекста: ${contextSize} сообщений`);
});

// Обработка команды /help
bot.onText(/\/help/, async (msg) => {
    const userId = msg.from.id.toString();
    const isAdminUser = isAdmin(userId);
    
    let helpMessage = 'Доступные команды:\n\n' +
        '/start - Начать общение\n' +
        '/clear - Очистить контекст\n' +
        '/context - Показать размер контекста\n' +
        '/help - Показать это сообщение\n' +
        '/id - Показать ваш Telegram ID';

    if (isAdminUser) {
        helpMessage += '\n\nКоманды администратора:\n' +
            '/stats - Статистика использования\n' +
            '/block [user_id] - Заблокировать пользователя\n' +
            '/unblock [user_id] - Разблокировать пользователя\n' +
            '/setcontext [user_id] [limit] - Установить лимит контекста';
    }

    bot.sendMessage(userId, helpMessage);
});

// Новая команда для получения ID
bot.onText(/\/id/, (msg) => {
    const userId = msg.from.id.toString();
    bot.sendMessage(userId, `Ваш Telegram ID: ${userId}`);
    console.log('Запрошен ID пользователя:', userId);
});

// Административные команды
bot.onText(/\/stats/, async (msg) => {
    const userId = msg.from.id.toString();
    if (!isAdmin(userId)) {
        bot.sendMessage(userId, 'У вас нет прав для использования этой команды.');
        return;
    }

    const userData = await loadUserData();
    const stats = {
        totalUsers: Object.keys(userData.users).length,
        activeUsers: Object.values(userData.users).filter(u => u.status === 'active').length,
        blockedUsers: Object.values(userData.users).filter(u => u.status === 'blocked').length
    };

    const message = `Статистика:\n` +
        `Всего пользователей: ${stats.totalUsers}\n` +
        `Активных пользователей: ${stats.activeUsers}\n` +
        `Заблокированных пользователей: ${stats.blockedUsers}`;

    bot.sendMessage(userId, message);
});

// Обработка обычных сообщений
bot.on('message', async (msg) => {
    if (msg.text.startsWith('/')) return; // Пропускаем команды

    const userId = msg.from.id.toString();
    console.log('Получено сообщение от пользователя с ID:', userId);
    console.log('Текст сообщения:', msg.text);
    
    const userData = await loadUserData();
    
    if (!userData.users[userId] || userData.users[userId].status === 'blocked') {
        return;
    }

    try {
        // Получаем или создаем контекст пользователя
        let userContext = userContexts.get(userId) || await loadContext(userId) || [];
        
        // Добавляем сообщение пользователя в контекст
        userContext.push({
            role: 'user',
            content: msg.text,
            timestamp: new Date().toISOString()
        });

        // Ограничиваем размер контекста
        const contextLimit = userData.users[userId].contextLimit;
        if (userContext.length > contextLimit) {
            userContext = userContext.slice(-contextLimit);
        }

        // Отправляем "печатает..."
        bot.sendChatAction(userId, 'typing');

        // Получаем ответ от OpenRouter
        const response = await openRouter.generateResponse(userContext);
        
        // Добавляем ответ бота в контекст
        userContext.push({
            role: 'assistant',
            content: response,
            timestamp: new Date().toISOString()
        });

        // Сохраняем обновленный контекст
        userContexts.set(userId, userContext);
        await saveContext(userId, userContext);

        // Отправляем ответ пользователю
        await bot.sendMessage(userId, response);

        // Обновляем время последней активности
        userData.users[userId].lastActive = new Date().toISOString();
        await saveUserData(userData);
    } catch (error) {
        console.error('Error processing message:', error);
        bot.sendMessage(userId, 'Произошла ошибка при обработке вашего сообщения. Пожалуйста, попробуйте позже.');
    }
});

// Обработка ошибок
bot.on('polling_error', (error) => {
    console.error('Polling error:', error);
});

// Периодическая очистка старых контекстов
setInterval(async () => {
    const userData = await loadUserData();
    const now = new Date();
    
    for (const [userId, context] of userContexts.entries()) {
        const lastActive = new Date(userData.users[userId]?.lastActive || 0);
        if (now - lastActive > config.defaults.userTimeout * 1000) {
            userContexts.delete(userId);
            await fs.unlink(path.join(__dirname, 'data/contexts', `${userId}.json`)).catch(() => {});
        }
    }
}, config.defaults.userTimeout * 1000);

console.log('Бот запущен и ожидает сообщений...');
console.log('Текущая конфигурация:', {
    adminId: config.adminId,
    contextLimit: config.defaults.contextLimit,
    adminContextLimit: config.defaults.adminContextLimit
});
