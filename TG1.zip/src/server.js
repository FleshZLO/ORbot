const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const cors = require('cors');
const path = require('path');
const fs = require('fs').promises;
const config = require('./config/config');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet({
    contentSecurityPolicy: false
}));

app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Настройка сессии
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false,
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000 // 24 часа
    }
}));

// Логирование запросов
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} ${req.method} ${req.url}`);
    if (req.body && Object.keys(req.body).length > 0) {
        console.log('Request body:', JSON.stringify(req.body, null, 2));
    }
    next();
});

// Middleware для проверки аутентификации
const requireAuth = (req, res, next) => {
    console.log('Session check:', req.session);
    if (req.session.authenticated) {
        next();
    } else {
        res.status(401).json({ error: 'Unauthorized' });
    }
};

// Роуты аутентификации
app.post('/api/login', (req, res) => {
    console.log('Login attempt:', req.body);
    const { username, password } = req.body;
    
    if (username === config.admin.username && password === config.admin.password) {
        req.session.authenticated = true;
        req.session.username = username;
        console.log('Login successful:', username);
        res.json({ success: true });
    } else {
        console.log('Login failed:', username);
        res.status(401).json({ error: 'Invalid credentials' });
    }
});

app.post('/api/logout', (req, res) => {
    console.log('Logout:', req.session.username);
    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err);
            res.status(500).json({ error: 'Failed to logout' });
        } else {
            res.json({ success: true });
        }
    });
});

// API роуты
app.get('/api/users', requireAuth, async (req, res) => {
    try {
        const data = await fs.readFile(path.join(__dirname, 'data/users.json'), 'utf8');
        res.json(JSON.parse(data));
    } catch (error) {
        console.error('Failed to load users:', error);
        res.status(500).json({ error: 'Failed to load users' });
    }
});

app.put('/api/users/:userId', requireAuth, async (req, res) => {
    try {
        const { userId } = req.params;
        const { contextLimit, status } = req.body;
        console.log('Update user request:', { userId, contextLimit, status });
        
        const data = await fs.readFile(path.join(__dirname, 'data/users.json'), 'utf8');
        const userData = JSON.parse(data);
        
        if (!userData.users[userId]) {
            return res.status(404).json({ error: 'User not found' });
        }

        if (contextLimit !== undefined) {
            userData.users[userId].contextLimit = contextLimit;
        }
        if (status !== undefined) {
            userData.users[userId].status = status;
        }

        await fs.writeFile(
            path.join(__dirname, 'data/users.json'),
            JSON.stringify(userData, null, 2)
        );

        console.log('User updated:', userId);
        res.json({ success: true });
    } catch (error) {
        console.error('Failed to update user:', error);
        res.status(500).json({ error: 'Failed to update user' });
    }
});

app.get('/api/stats', requireAuth, async (req, res) => {
    try {
        const data = await fs.readFile(path.join(__dirname, 'data/users.json'), 'utf8');
        const userData = JSON.parse(data);
        
        const stats = {
            totalUsers: Object.keys(userData.users).length,
            activeUsers: Object.values(userData.users).filter(u => u.status === 'active').length,
            blockedUsers: Object.values(userData.users).filter(u => u.status === 'blocked').length
        };

        console.log('Stats requested:', stats);
        res.json(stats);
    } catch (error) {
        console.error('Failed to load stats:', error);
        res.status(500).json({ error: 'Failed to load stats' });
    }
});

// Обработка ошибок
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({ error: 'Internal Server Error' });
});

// Маршрут для всех остальных запросов (SPA)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`Сервер запущен на порту ${PORT}`);
});

// Обработка необработанных ошибок
process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (error) => {
    console.error('Unhandled Rejection:', error);
});
